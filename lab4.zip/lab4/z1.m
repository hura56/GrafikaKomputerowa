clear;
img = imread('rzeczka.jpg');
img = double(img) /255;
#zmiana gamma
gamma = 1.5;
img2 = img .^(1/gamma);

#funkcje porownujace
###VPS
#funkcja liczy modu� z r�nicy mi�dzy warto�ci� now� a star�,
function vps_diff = VPS(obraz_stary, obraz_nowy, mnoznik)
  #sprawdzenie rozmiarow
  if size(obraz_stary) ~= size(obraz_nowy)
    error('Obrazy nie maja takich samych wymiarow');
    end
  #roznica miedzy obrazami
  roznica = abs(obraz_nowy - obraz_stary);
  vps_diff = roznica * mnoznik;
end
###POROWNANIE V2
#funkcja liczy r�nic� z r�nicy z warto�ci nowej a star� i warto�ci� �rodkow� (127.5)
function v2_diff = porownanie_v2(obraz_stary, obraz_nowy, mnoznik)
    #sprawdzenie rozmiarow
    if size(obraz_stary) ~= size(obraz_nowy)
        error('Obrazy nie maja takich samych wymiarow');
    end
    #w.srodkowa
    srodkowa = 0.5;
    
    v2_diff = (mnoznik * (obraz_nowy - obraz_stary) + srodkowa);
end
wynik_vps = VPS(img, img2, 4);
#przycinanie zakresu
wynik_vps(wynik_vps > 255) = 255;
wynik_vps(wynik_vps < 0) = 0;

#v2
wynik_v2 = porownanie_v2(img, img2, 3);
wynik_v2(wynik_v2 > 255) = 255;
wynik_v2(wynik_v2 < 0) = 0;

subplot(2,2,1)
imshow(img);
title('org');

subplot(2,2,2)
imshow(img2);
title('gammma 1.5');

subplot(2,2,3)
imshow(wynik_vps);
title('porownanie v.PS * 4');

subplot(2,2,4)
imshow(wynik_v2);
title('porownanie v2 * 3');