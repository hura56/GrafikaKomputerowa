clear
% Wczytaj obrazek
image = imread('rzeczka2.png');

% Przeskaluj obrazek do zakresu [0, 1]
image = double(image) / 255;

% Warto�� gamma
gamma = 1.5;

% Wykonaj korekcj� gamma
adjusted_image = image .^(1/gamma);

% Wy�wietl obrazy przed i po korekcji gamma
subplot(2, 2, 1);
imshow(image);
title('Obraz przed korekcj� gamma');

subplot(2, 2, 2);
imshow(adjusted_image);
title('Obraz po korekcji gamma');

subplot(2, 2, 3);
x = linspace(0, 1, 256);
y = x .^ (1/gamma);
plot(x, y);
title('transformacja gamma 1.5');
xlabel('Warto�� wej�ciowa');
ylabel('Warto�� wyj�ciowa');
