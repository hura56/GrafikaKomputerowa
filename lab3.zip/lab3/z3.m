clear

% Wczytaj obrazek
image = imread('rzeczka2.png');

% zamiana na double
image = double(image);

# Zmiana jasno�ci o +50
image_jasny = image +50;

# Zmiana jasno�ci o -50
image_ciemny = image -50;

# Przycinanie jasnego
image_jasny(image_jasny < 0) = 0;
image_jasny(image_jasny > 255) = 255;

# Przycinanie ciemnego
image_ciemny(image_ciemny < 0) = 0;
image_ciemny(image_ciemny > 255) = 255;

% Wy�wietl obrazy przed i po korekcji
subplot(2, 2, 1);
imshow(image/255);
title('Obraz org');

subplot(2, 2, 2);
imshow(image_jasny/255);
title('Obraz rozja�niony');

subplot(2, 2, 3);
imshow(image_ciemny/255);
title('Obraz �ciemniony');

subplot(2, 2, 4);
x = linspace(0, 1, 255);
y = x .^ (1/gamma);
