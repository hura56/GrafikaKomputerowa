% Wczytaj obrazek
image = imread('rzeczka2.png');

% Zamiana na double
image = double(image);

% Zmiana jasno�ci o +50
image_jasny = image + 50;

% Ustawienie warto�ci mniejszych od 0 na 0
image_jasny(image_jasny < 0) = 0;

% Ustawienie warto�ci wi�kszych od 255 na 255
image_jasny(image_jasny > 255) = 255;

% Tworzenie wektora z jasno�ciami
x = linspace(0, 255, 256);

% Oblicz histogramy
hist_original = hist(reshape(image, [], 1), x);
hist_adjusted = hist(reshape(image_jasny, [], 1), x);

% Normalizacja do prawdopodobie�stwa
hist_original = hist_original / numel(image);
hist_adjusted = hist_adjusted / numel(image_jasny);

% Wy�wietl wykres
figure;
plot(x, hist_original, 'b', 'LineWidth', 2, 'DisplayName', 'Przed');
hold on;
plot(x, hist_adjusted, 'r', 'LineWidth', 2, 'DisplayName', 'Po');
title('Transformacja jasno�ci');
xlabel('Warto�� jasno�ci');
ylabel('Prawdopodobie�stwo');
legend;
